/**
 * Contains infrastructure and helpers needed for running the E2E tests.
 */
package teammates.e2e.util;
