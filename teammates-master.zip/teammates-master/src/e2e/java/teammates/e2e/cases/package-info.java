/**
 * Contains E2E test cases.
 */
package teammates.e2e.cases;
