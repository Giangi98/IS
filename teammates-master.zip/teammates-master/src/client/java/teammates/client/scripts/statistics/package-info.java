/**
 * Contains scripts that calculate the statistics per institute.
 */
package teammates.client.scripts.statistics;
