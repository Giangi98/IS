/**
 * Contains all API output formats.
 */
package teammates.ui.output;
