package teammates.ui.request;

/**
 * The update request of a feedback session.
 */
public class FeedbackSessionUpdateRequest extends FeedbackSessionBasicRequest {

}
