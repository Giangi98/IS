package teammates.ui.request;

/**
 * The update request of a feedback question.
 */
public class FeedbackQuestionUpdateRequest extends FeedbackQuestionBasicRequest {
}
