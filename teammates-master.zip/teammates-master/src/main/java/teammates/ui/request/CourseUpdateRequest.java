package teammates.ui.request;

/**
 * The update request for a course.
 */
public class CourseUpdateRequest extends CourseBasicRequest {
}
