/**
 * Contains all constants to be shared with the front-end.
 */
package teammates.ui.constants;
