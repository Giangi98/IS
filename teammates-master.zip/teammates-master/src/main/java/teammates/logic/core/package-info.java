/**
 * Contains the core logic of the system.
 */
package teammates.logic.core;
