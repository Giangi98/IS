/**
 * Contains a single class as the entrypoint to the system.
 */
package teammates.main;
