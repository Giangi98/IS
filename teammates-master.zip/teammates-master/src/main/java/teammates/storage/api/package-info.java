/**
 * Provides the API of the component to be accessed by the logic component.
 */
package teammates.storage.api;
