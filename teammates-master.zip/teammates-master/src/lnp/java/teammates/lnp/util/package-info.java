/**
 * Contains infrastructure and helpers needed for running the L&P tests.
 */
package teammates.lnp.util;
