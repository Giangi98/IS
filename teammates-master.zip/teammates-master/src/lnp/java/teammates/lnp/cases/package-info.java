/**
 * Contains L&P test cases.
 */
package teammates.lnp.cases;
